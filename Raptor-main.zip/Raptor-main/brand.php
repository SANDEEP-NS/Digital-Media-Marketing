<?php
// Step 2a: Connect to the database using a database connection string
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'edp';

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

if (!$conn) {
  die('Could not connect: ' . mysqli_error($conn));
}

// Step 2b: Get the form data from the $_POST and $_FILES superglobal arrays
$brandname = mysqli_real_escape_string($conn, $_POST['brandname']);
$description = mysqli_real_escape_string($conn, $_POST['description']);
$launchdate = mysqli_real_escape_string($conn, $_POST['launchdate']);
$brandRating = $_POST['ratings'];
$filename = mysqli_real_escape_string($conn, $_FILES['fileupload']['name']);
$filetype = mysqli_real_escape_string($conn, $_FILES['fileupload']['type']);
$filedata = mysqli_real_escape_string($conn, file_get_contents($_FILES['fileupload']['tmp_name']));
$preferedPlatform = $_POST['prefered_platform'];

// Step 2c: Insert the form data into the database using a SQL INSERT statement
$sql = "INSERT INTO brand_detail (brandname, description, launchdate, ratings, filename, filetype, filedata, preferedPlatform) VALUES ('$brandname', '$description', '$launchdate', '$brandRating', '$filename', '$filetype', '$filedata', '$preferedPlatform')";

if ($conn->query($sql) === TRUE) {
    echo "Your Brand Datas has been collected !. Please make a call from our home page to Promote your brand.";
 } else {
   echo "Error: " . $sql . "<br>" . $conn->error;
 }

// Step 2d: Close the database connection
mysqli_close($conn);
?>
