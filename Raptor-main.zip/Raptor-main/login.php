<?php
session_start();

// Connect to database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "edp";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get form data
$username = $_POST["uname"];
$passwrd = $_POST["psw"];

// Query database for matching username and password
$sql = "SELECT * FROM sign_up WHERE username='$username' AND passwrd='$passwrd'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // User found, redirect to dashboard
  $_SESSION["username"] = $username;
  echo "Login successful!";
  header("Location: main.html");
} else {
  // Invalid login credentials
  echo "Invalid username or password";
}

$conn->close();
?>
