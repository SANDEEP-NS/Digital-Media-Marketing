<?php
// Connect to database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "edp";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get form data
$username = $_POST["username"];
$age = $_POST["age"];
$gender = $_POST["gender"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$passwrd = $_POST["password"];

// Validate form data (e.g., check password length, validate email format)

// Insert data into database
$sql = "INSERT INTO sign_up (username, age, gender, email, phone, passwrd)
        VALUES ('$username', $age, '$gender', '$email', $phone, '$passwrd')";

if ($conn->query($sql) === TRUE) {
   echo "User created successfully. Please log in.";
   header("Location: login.html");
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

