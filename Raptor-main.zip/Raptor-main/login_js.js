function user_focus(focus_style)
{
    focus_style.style.backgroundColor = "lightblue";
}

function user_blur(focus_style)
{
    focus_style.style.backgroundColor = "white";
}

function auth()
{
    
    uname = ["sandeep","vengatesh","madhumaran"];
    //emails = ["infant@student.tce.edu","archana@student.tce.edu","guhan@student.tce.edu"];
    pword = ["s@2003","v@2002","m@2000"];
    var user_name = document.getElementById("user_field").value;
    var pass_word = document.getElementById("password_field").value;
    //var email_id = document.getElementById("email_field").value;
    if(uname.includes(user_name) && pword.includes(pass_word))
    {
        alert("Signed In Successfully!");
        //document.getElementById("home_name").innerHTML = user_name;
        window.location.href = "./exp1.html";
    }
    else
    {
        document.getElementById("auth_message").innerHTML = "<span style = 'color : red'>Invalid Username/Password";
        // return false
    }
    
}


function move_down(event , field_id)
{
    if(event.keyCode === 13)
    {
        document.getElementById(field_id).focus();
    }
}